# snek

Snake game implemented using `gg` module. 

# Compiling & running

## Compiling to binary
```sh
v -prod examples/snek/snek.v
./examples/snek/snek # run snek game!
```

## Compiling to JS
```sh
v -b js_browser examples/snek/snek.js.v
```
And then open `examples/snek/index.html` in your favourite browser.