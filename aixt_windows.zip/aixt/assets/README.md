<!-- Project Name: Aixt, https://github.com/fermarsan/aixt.git
Authors:
    - Santiago Orjuela
    - Fernando M. Santa
Date: 2022
License: MIT -->

The pet of the project is an otter named _Aixtü_. This name is a way to write otter in [_Ticuna_](https://www.sil.org/system/files/reapdata/90/20/51/90205190508691852389084667097660892450/tca_Ticuna_Dictionary_2016_web.pdf) language.

Created using [**DALL-E 2**](https://openai.com/dall-e-2/).