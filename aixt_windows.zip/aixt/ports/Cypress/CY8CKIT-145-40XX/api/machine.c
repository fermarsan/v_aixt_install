// Project Name: Aixt, https://github.com/fermarsan/aixt.git
// Authors:
//	- Javier Leon
//	- Camilo Lucas
//	- Fernando M. Santa
// Date: 2023
// License: MIT
//
// Description: Includes all machine modules
//              (CY8CKIT-145-40XX)
#include "./machine/pin.c"
// #include "./machine/uart.c"
